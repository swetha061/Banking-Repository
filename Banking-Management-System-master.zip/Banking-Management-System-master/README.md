# Banking-Management-System
A Database Driven Banking-Management-System using Java.

To setup the project on your local machine:

 1. Click on `Fork`.
 2. Go to your fork and `clone` the project to your local machine.
 3. git clone `https://github.com/kumarcodes/Banking-Management-System.git`

